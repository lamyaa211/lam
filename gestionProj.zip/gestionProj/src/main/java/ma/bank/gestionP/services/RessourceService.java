package ma.bank.gestionP.services;

import ma.bank.gestionP.models.Ressource;
import ma.bank.gestionP.repositories.RessourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RessourceService {
    private RessourceRepository ressourceRepository;

    @Autowired
    public RessourceService(RessourceRepository ressourceRepository) {
        this.ressourceRepository = ressourceRepository;
    }

    public List<Ressource> getAllRessources() {
        return ressourceRepository.findAll();
    }

    public void ajouterRessource(Ressource ressource) {
        ressourceRepository.save(ressource);
    }

    public Ressource getRessourceById(Long id) {
        Optional<Ressource> optionalRessource = ressourceRepository.findById(id);
        return optionalRessource.orElse(null);
    }

    public void modifierRessource(Ressource ressource) {
        ressourceRepository.save(ressource);
    }

    public void supprimerRessource(Long id) {
        ressourceRepository.deleteById(id);
    }

    public boolean isNomRessourceUnique(String nom) {
        Ressource ressource = ressourceRepository.findByNom(nom);
        return ressource == null;
    }
}

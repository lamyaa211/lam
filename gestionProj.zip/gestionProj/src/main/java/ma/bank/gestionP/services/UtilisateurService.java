package ma.bank.gestionP.services;

import ma.bank.gestionP.models.Ressource;
import ma.bank.gestionP.models.Utilisateur;
import ma.bank.gestionP.repositories.UtilisateurRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import ma.bank.gestionP.repositories.RessourceRepository;


@Service
public class UtilisateurService {
    private UtilisateurRepository utilisateurRepository;
    private RessourceRepository ressourceRepository;

    @Autowired
    public UtilisateurService(UtilisateurRepository utilisateurRepository, RessourceRepository ressourceRepository) {
        this.utilisateurRepository = utilisateurRepository;
        this.ressourceRepository = ressourceRepository;
    }

    public Utilisateur getUserByUsername(String username) {
        return utilisateurRepository.findByUsername(username);
    }

    public boolean utilisateurExiste(String username) {
        return utilisateurRepository.existsByUsername(username);
    }

    public void saveUtilisateur(Utilisateur nouvelUtilisateur) {
        utilisateurRepository.save(nouvelUtilisateur);
    }

    public List<Ressource> getAllRessources() {
        return ressourceRepository.findAll();
    }
}

















package ma.bank.gestionP.repositories;

import ma.bank.gestionP.models.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UtilisateurRepository extends JpaRepository<Utilisateur, Long> {
    Utilisateur findByUsername(String nom);

    boolean existsByUsername(String nom);
}

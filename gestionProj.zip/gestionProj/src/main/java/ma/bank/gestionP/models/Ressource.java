package ma.bank.gestionP.models;

import jakarta.persistence.*;

@Entity
@Table(name = "ressources")
public class Ressource {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;
    private String prenom;

    @Column(name = "type_poste")
    private String typePoste;

    @Column(name = "type_profil")
    private String typeProfil;

    public Ressource() {
    }

    public Ressource(String nom, String prenom, String typePoste, String typeProfil) {
        this.nom = nom;
        this.prenom = prenom;
        this.typePoste = typePoste;
        this.typeProfil = typeProfil;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getTypePoste() {
        return typePoste;
    }

    public void setTypePoste(String typePoste) {
        this.typePoste = typePoste;
    }

    public String getTypeProfil() {
        return typeProfil;
    }

    public void setTypeProfil(String typeProfil) {
        this.typeProfil = typeProfil;
    }
}

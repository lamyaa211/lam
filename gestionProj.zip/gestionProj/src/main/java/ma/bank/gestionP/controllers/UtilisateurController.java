package ma.bank.gestionP.controllers;

import jakarta.servlet.http.HttpSession;
import ma.bank.gestionP.models.Utilisateur;
import ma.bank.gestionP.services.UtilisateurService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class UtilisateurController {
    @Autowired
    private UtilisateurService utilisateurService;

    public UtilisateurController(UtilisateurService utilisateurService) {
        this.utilisateurService = utilisateurService;
    }

    @GetMapping("/")
    public String login() {
        return "login";
    }
    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @PostMapping("/home")
    public String home(@RequestParam("username") String username, @RequestParam("password") String password, RedirectAttributes redirectAttributes) {
        if (utilisateurService.utilisateurExiste(username)) {
            // Si l'utilisateur existe, vérifiez les informations de connexion
            Utilisateur utilisateur = utilisateurService.getUserByUsername(username);

            if (utilisateur.getMotDePasse().equals(password)) {
                // Si le mot de passe correspond, ajoutez le nom de l'utilisateur aux attributs de redirection
                redirectAttributes.addAttribute("nomUtilisateur", utilisateur.getNom());
                return "redirect:/home";
            } else {
                // Sinon, redirigez vers la page de connexion avec un message d'erreur
                return "redirect:/login?error=true";
            }
        } else {
            return "redirect:/login?error=true";
        }
    }





    @PostMapping("/register")
    public String register(@RequestParam("username") String username, @RequestParam("password") String password,RedirectAttributes redirectAttributes) {
        // Créez un nouvel utilisateur avec les informations fournies
        Utilisateur nouvelUtilisateur = new Utilisateur();
        nouvelUtilisateur.setNom(username);
        nouvelUtilisateur.setMotDePasse(password);

        // Enregistrez le nouvel utilisateur dans la base de données
        utilisateurService.saveUtilisateur(nouvelUtilisateur);
        redirectAttributes.addAttribute("nomUtilisateur", nouvelUtilisateur.getNom());
        return "redirect:/home";
    }
}

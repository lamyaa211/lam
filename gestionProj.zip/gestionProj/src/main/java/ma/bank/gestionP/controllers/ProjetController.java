package ma.bank.gestionP.controllers;

import ma.bank.gestionP.models.Projet;
import ma.bank.gestionP.services.ProjetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller

public class ProjetController {
    private ProjetService projetService;

    @Autowired
    public ProjetController(ProjetService projetService) {
        this.projetService = projetService;
    }

    @GetMapping("/addproject")
    public String afficherFormulaireAjout(Model model) {
        model.addAttribute("newProjet", new Projet());
        return "addproject";
    }
    @GetMapping("/projet")
    public String afficherListeProjets(Model model) {
        List<Projet> projets = projetService.getAllProjets();
        model.addAttribute("projets", projets);
        return "projet";
    }

    @PostMapping("/addproject")
    public String ajouterProjet(@ModelAttribute("newProjet") Projet projet) {
        projetService.ajouterProjet(projet);
        return "redirect:/projet";
    }

    @GetMapping("/modifierprojet/{id}")
    public String afficherFormulaireModification(@PathVariable("id") Long id, Model model) {
        Projet projet = projetService.getProjetById(id);
        if (projet != null) {
            model.addAttribute("projet", projet);
            return "modifier-projet";
        }
        return "redirect:/projet";
    }

    @PostMapping("/modifierprojet")
    public String modifierProjet(@ModelAttribute("projet") Projet projet) {
        projetService.modifierProjet(projet);
        return "redirect:/projet";
    }



    @GetMapping("/supprimerprojet/{id}")
        public String supprimerProjet(@PathVariable("id") long id) {
        projetService.supprimerProjetById(id);
        return "redirect:/projet";
    }
}

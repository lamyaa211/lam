package ma.bank.gestionP.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Projet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titre;
    private String phase;
    private String activites;
    private String livrables;
    private double chargeConsomme;
    private double chargeInitiale;
    private double chargeRevisee;
    private int mois;
    private int semaine;
    private String commentaire;

    public Projet() {
    }

    public Projet(String titre, String phase, String activites, String livrables, double chargeConsomme,
                  double chargeInitiale, double chargeRevisee, int mois, int semaine, String commentaire) {
        this.titre = titre;
        this.phase = phase;
        this.activites = activites;
        this.livrables = livrables;
        this.chargeConsomme = chargeConsomme;
        this.chargeInitiale = chargeInitiale;
        this.chargeRevisee = chargeRevisee;
        this.mois = mois;
        this.semaine = semaine;
        this.commentaire = commentaire;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public String getActivites() {
        return activites;
    }

    public void setActivites(String activites) {
        this.activites = activites;
    }

    public String getLivrables() {
        return livrables;
    }

    public void setLivrables(String livrables) {
        this.livrables = livrables;
    }

    public double getChargeConsomme() {
        return chargeConsomme;
    }

    public void setChargeConsomme(double chargeConsomme) {
        this.chargeConsomme = chargeConsomme;
    }

    public double getChargeInitiale() {
        return chargeInitiale;
    }

    public void setChargeInitiale(double chargeInitiale) {
        this.chargeInitiale = chargeInitiale;
    }

    public double getChargeRevisee() {
        return chargeRevisee;
    }

    public void setChargeRevisee(double chargeRevisee) {
        this.chargeRevisee = chargeRevisee;
    }

    public int getMois() {
        return mois;
    }

    public void setMois(int mois) {
        this.mois = mois;
    }

    public int getSemaine() {
        return semaine;
    }

    public void setSemaine(int semaine) {
        this.semaine = semaine;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }
}

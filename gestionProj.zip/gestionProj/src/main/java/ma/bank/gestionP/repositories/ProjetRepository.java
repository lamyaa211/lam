package ma.bank.gestionP.repositories;

import ma.bank.gestionP.models.Projet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjetRepository extends JpaRepository<Projet, Long> {
    Projet findByTitre(String titre);
}

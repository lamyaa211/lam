package ma.bank.gestionP.controllers;

import ma.bank.gestionP.models.Ressource;
import ma.bank.gestionP.services.RessourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/ressources")
public class RessourceController {
    private RessourceService ressourceService;

    @Autowired
    public RessourceController(RessourceService ressourceService) {
        this.ressourceService = ressourceService;
    }

    @GetMapping("/ressources/liste")
    public String afficherRessources(Model model) {
        List<Ressource> ressources = ressourceService.getAllRessources();
        model.addAttribute("ressources", ressources);
        return "ressources";
    }


    @PostMapping("/ajouterRessource")
    public String ajouterRessource(@ModelAttribute("newRessource") Ressource ressource) {
        ressourceService.ajouterRessource(ressource);
        return "redirect:/home";
    }


    @GetMapping("/modifier/{id}")
    public String afficherFormulaireModification(@PathVariable("id") Long id, Model model) {
        Ressource ressource = ressourceService.getRessourceById(id);
        if (ressource != null) {
            model.addAttribute("ressource", ressource);
            return "modifier-ressource";
        }
        return "redirect:/ressources/liste";
    }





}

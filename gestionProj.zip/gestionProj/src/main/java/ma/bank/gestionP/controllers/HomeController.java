package ma.bank.gestionP.controllers;

import ma.bank.gestionP.models.Projet;
import ma.bank.gestionP.models.Ressource;
import ma.bank.gestionP.services.ProjetService;
import ma.bank.gestionP.services.RessourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class HomeController {
    private RessourceService ressourceService;
    private ProjetService projetService;
    @Autowired
    public HomeController(RessourceService ressourceService) {
        this.ressourceService = ressourceService;
    }

    @GetMapping("/home")
    public String home(Model model) {
        List<Ressource> ressources = ressourceService.getAllRessources();
        model.addAttribute("ressources", ressources);
        model.addAttribute("newRessource", new Ressource());
        model.addAttribute("showTable", false);
        return "home";
    }
    @GetMapping("/addressource")
    public String ajoutRessource() {
        return "addressource";
    }


    @GetMapping("/getressource/{id}")
    public String getressource(@PathVariable("id") Long id, Model model) {
       Ressource ressource = ressourceService.getRessourceById(id);
        model.addAttribute("ressource", ressource);
        return "show-ressource";
    }

    @PostMapping("/ajouterRessource")
    public String ajouterRessource(@ModelAttribute("newRessource") Ressource ressource) {
        ressourceService.ajouterRessource(ressource);
        return "redirect:/ressource";
    }
    @GetMapping("/ressource")
    public String afficherRessources(Model model) {
        List<Ressource> ressources = ressourceService.getAllRessources();
        model.addAttribute("ressources", ressources);
        return "ressource";
    }

    @GetMapping("/supprimer/{id}")
    public String supprimerRessource(@PathVariable("id") Long id) {
        ressourceService.supprimerRessource(id);
        return "redirect:/ressource";
    }

    @GetMapping("/modifier/{id}")
    public String afficherFormModifier(@PathVariable("id") Long id, Model model) {
        Ressource ressource = ressourceService.getRessourceById(id);
        model.addAttribute("ressource", ressource);
        return "modifier-ressource"; // Replace with the actual name of your update form view
    }

    // POST request to handle the update form submission
    @PostMapping("/modifier")
    public String modifierRessource(@ModelAttribute("ressource") Ressource ressource) {
        ressourceService.modifierRessource(ressource);
        return "redirect:/ressource"; // Replace with the appropriate URL after the resource is updated
    }
}
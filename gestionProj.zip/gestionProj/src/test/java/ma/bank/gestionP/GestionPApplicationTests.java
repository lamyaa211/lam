package ma.bank.gestionP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPApplicationTests {

	@Test
	void contextLoads() {
	}

}
